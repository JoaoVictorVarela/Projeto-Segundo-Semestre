<?php
session_start();

if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    unset($_SESSION['tipo_usuario']);
    
    header('Location: login.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faça sua reserva</title>
</head>
<body>

    <form action="cadastraNovaSenha.php" method='post'>
        <input type="email" name="nome_reserva" placeholder="Digite o nome da reserva" required><br><br>

        <input id="CPF" type="text" name="cpf" placeholder="Digite seu CPF" required><br><br>

        <input id="CEP" type="text" name="cep" placeholder="Digite seu CEP" required><br><br>

        <label for="data">Insira sua data de nascimento</label><br>

        <input type="date" id="data" name="data_nascimento" required><br><br>

        <input type="text" name="nome_materno" placeholder="Digite o nome da sua mãe" required><br><br>

        <input minlength="8" type="password" name="senha" placeholder="Digite sua nova senha" required><br><br>

        <input minlength="8" type="password" name="senha_conf" placeholder="Confirme sua nova senha" required><br><br>

        <input type="submit" value="enviar">

        <p>Tela Principal<a href="index.php"> Clique aqui</a>
        <p>Login<a href="login.php"> Clique aqui</a>
    </form>
    <a href="index.php"> Home</a>
</body>
</html>